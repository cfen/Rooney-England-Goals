c3 [![Build Status](https://travis-ci.org/masayuki0812/c3.png?branch=master)](https://travis-ci.org/masayuki0812/c3)
==

c3 is a D3-based reusable chart library that enables deeper integration of charts into web applications.

More information is here: [http://c3js.org](http://c3js.org/)

+ [Getting Started](http://c3js.org/gettingstarted.html)
+ [Examples](http://c3js.org/examples.html)
